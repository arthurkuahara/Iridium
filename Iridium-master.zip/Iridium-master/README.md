### References and inspirations

* [Writing a simple inverted index in python](https://medium.com/@fro_g/writing-a-simple-inverted-index-in-python-3c8bcb52169a)
