from math import log


def search(index,querry,number_of_docs):
    
    vectorial_space = {}
    
    for term in index.db.keys():
        for document in db[term].keys():
            if document in vectorial_space:
                
    
    
        
        
        
        

